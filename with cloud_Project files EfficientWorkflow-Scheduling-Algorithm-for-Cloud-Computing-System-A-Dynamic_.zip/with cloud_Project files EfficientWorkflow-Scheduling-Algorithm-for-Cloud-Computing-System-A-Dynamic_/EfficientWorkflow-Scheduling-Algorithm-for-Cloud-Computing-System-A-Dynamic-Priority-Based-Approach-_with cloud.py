#code for With cloud servers
import numpy as np
#DAG Graph Matrix for Given Workflow--------------------------------------------
matrix= np.loadtxt("Dagdata.txt", dtype='i', delimiter=',')
print(matrix)
(r,c)=matrix.shape  #rows and cols
Tmatrix=np.array(matrix).transpose() #transpose matrix
# for entry tasks finding from DAG---------------------------------------
en_task=[]
for i in range(r):
    count=0
    for j in range(c):
        if Tmatrix[i][j]==0:
            count+=1
    if count==r:
        en_task.append(i)
print("Entry tasks are:",en_task)
#for exit tasks finding from DAG-------------------------------------
ex_task=[]
for i in range(r):
    count=0
    for j in range(c):
        if matrix[i][j]==0:
            count+=1
    if count==r:
        ex_task.append(i)
print("exit_tasks are:",ex_task)
#for predecessor tasks
pred=[]
for i in range(r):
    emp=[]
    for j in range(c):
        if Tmatrix[i][j]>0:
            emp.append(j)
    pred.append(emp)
print("predecessors list for tasks labelled from 0 to "+str(len(pred))+" are:",pred)
for i in range(len(pred)):
    print("predecessor tasks for Task_"+str(i)+" are:",pred[i])
#ECT matrix----------------
Ect= np.loadtxt("ectdata.txt", dtype='i', delimiter=',')
print("Estimated computation time matrix ")
(vm,t)=Ect.shape
print(Ect)
print()
#defining cloud servers
c0_vm=[0,1]  #we need to  pre define
c1_vm=[2,3]
#for finding tasks in different levels
lev_tasks=[]
file=open("level_tasks.txt","r")
for line in file:
    lev_tasks.append(line.split())
print("tasks in each level labelled from 0 to "+str(len(lev_tasks))+" are:",lev_tasks)
print("no of levels are :",len(lev_tasks))
for i in range(len(lev_tasks)):
    print("tasks in Level_"+str(i)+" are:",lev_tasks[i])
#ACT finder---------------------------
ACT_s=[]
VM_assign=[]
for i in range(r):
    s=[]
    for j in range(vm):
        s.append(Ect[j][i])
    ind=s.index(min(s))
    VM_assign.append(ind)
    ACT_s.append(min(s))
print("Actual Completion Time :",ACT_s)
print("VM assigned :",VM_assign)
#for finding thresold values of each task
thr=[]                                     #thresold values calculator
for i in range(len(lev_tasks)):
    if i==0:
        for j in range(len(lev_tasks[i])):
            thr.append(0.99)
    else:
        tt_tasks = []
        m_Ect=[]
        for j in range(len(lev_tasks[i])):
            tt_tasks.append(int(lev_tasks[i][j]))
        print("tasks in level",i,":", tt_tasks)
        for k in tt_tasks:
            a = []
            for v in range(vm):
                a.append(Ect[v][k])
            m_Ect.append(max(a))  #max execution time needed for computation
        print("Max_exec Time needed for thresold calculation of each task in level :"+str(i))
        print(m_Ect)
        s_s=[]
        for k in range(len(lev_tasks[i])):
            DT_pred = []
            print("pred of :",tt_tasks[k])
            for j in range(len(pred[tt_tasks[k]])):
                DT_pred.append(pred[tt_tasks[k]][j])
            print(DT_pred)
            DT_time=[]
            for j in range(len(DT_pred)):
                z=tt_tasks[k]
                x=DT_pred[j]
                DT_time.append(matrix[x][z])
            print("Data T_time :",tt_tasks[k])
            print(DT_time)
            s_s.append(sum(DT_time))
        for j in range(len(s_s)):
            thr.append(float(m_Ect[j]/s_s[j]))
print("Threslod values of Each Tasks :",thr)
        #print("maximum of DT's :")
        #print(s_s)
print()
print("EST and EFT calculation Part-----------","\n")
EST = []
EFT = []
def COMP_EFT(EST,EFT):   #implementation of Algorithm -3----------------------------------------------
    avail = [0] * vm
    for i in range(len(lev_tasks)):
        print("tasks in level ", i, ":")
        if i == 0:  # for entry tasks
            tt_tasks = []
            for j in range(len(lev_tasks[i])):
                tt_tasks.append(int(lev_tasks[i][j]))
                EST.append(0)
                EFT.append(ACT_s[j])
            for j in tt_tasks:
                avail[VM_assign[j]] = ACT_s[j]
            # print(avail)
        else:
            tt_tasks = []
            temp_et = []
            for j in range(len(lev_tasks[i])):
                tt_tasks.append(int(lev_tasks[i][j]))
            for j in tt_tasks:
                z = []
                for k in range(vm):
                    t = []
                    if k in c0_vm:
                        for p in range(len(pred[j])):
                            if VM_assign[pred[j][p]] in c0_vm:
                                DT = 0
                                ACT_p = EFT[pred[j][p]]
                                t.append(ACT_p)
                            else:
                                DT = matrix[pred[j][p]][j]
                                ACT_p = EFT[pred[j][p]]
                                t.append(ACT_p + DT)
                        max_t = max(t)
                        z.append(max_t + Ect[k][j])
                        # print(z)
                    elif k in c1_vm:
                        for p in range(len(pred[j])):
                            if VM_assign[pred[j][p]] in c1_vm:
                                DT = 0
                                ACT_p = EFT[pred[j][p]]
                                t.append(ACT_p)
                            else:
                                DT = matrix[pred[j][p]][j]
                                ACT_p = EFT[pred[j][p]]
                                t.append(ACT_p + DT)
                        max_t = max(t)
                        z.append(max_t + Ect[k][j])
                EFT.append(min(z))
                temp_et.append(z)
                EST.append((EFT[j]) - ACT_s[j])
            print(np.matrix(temp_et))
            print()
    print("Required EFT :", EFT)
    print()
    print("Required EST :", EST)
    print("Tasks", "  ", "EST", " ", " EFT", "  ", "ACT")
    for i in range(len(EFT)):
        print(i, "     ", EST[i], "     ", EFT[i], "   ", ACT_s[i])
#Normalization finding part
print("Temp_ECT and N_temp_ECT matrix Calculation Part :---------------------------------")
B_large = []
B_small = []
def NORM_PARTITION(EST,EFT,B_large,B_small,thr):    #implementation   algorithm -4----------------------------
    for i in range(len(lev_tasks)):
        temp_et=[]
        t_tasks=[]
        print("IN LEVEL ",i,":")
        if i==0:
            for j in range(len(lev_tasks[i])):
                t_tasks.append(int(lev_tasks[i][j]))
            for k in range(len(t_tasks)):
                a = []
                for j in range(vm):
                    a.append(Ect[j][t_tasks[k]])
                temp_et.append(a)
            print("Temp_ECT :")
            print(np.matrix(temp_et))
        else:
            temp_et = []
            for j in range(len(lev_tasks[i])):
                t_tasks.append(int(lev_tasks[i][j]))
            for j in t_tasks:
                z = []
                for k in range(vm):
                    t = []
                    if k in c0_vm:
                        for p in range(len(pred[j])):
                            if VM_assign[pred[j][p]] in c0_vm:
                                DT = 0
                                ACT_p = EFT[pred[j][p]]
                                t.append(ACT_p)
                            else:
                                DT = matrix[pred[j][p]][j]
                                ACT_p = EFT[pred[j][p]]
                                t.append(ACT_p + DT)
                        max_t = max(t)
                        z.append(max_t + Ect[k][j])
                        # print(z)
                    elif k in c1_vm:
                        for p in range(len(pred[j])):
                            if VM_assign[pred[j][p]] in c1_vm:
                                DT = 0
                                ACT_p = EFT[pred[j][p]]
                                t.append(ACT_p)
                            else:
                                DT = matrix[pred[j][p]][j]
                                ACT_p = EFT[pred[j][p]]
                                t.append(ACT_p + DT)
                        max_t = max(t)
                        z.append(max_t + Ect[k][j])
                temp_et.append(z)
            print("Temp_ECT :")
            print(np.matrix(temp_et))
        for l in range(len(t_tasks)):
            for k in range(len(temp_et)):
                t_l = []
                for m in range(len(temp_et)):
                    for j in range(len(temp_et[m])):
                        t_l.append((temp_et[m][j]))
                min_ect = min(t_l)
                max_ect = max(t_l)
            diff = max_ect - min_ect
            n_temp = []
            for k in range(len(temp_et)):
                a = []
                for j in range(len(temp_et[k])):
                    l_1 = temp_et[k][j]
                    a.append((l_1 - min_ect) / diff)
                n_temp.append(a)
            z = []
            for k in range(len(n_temp)):
                z.append(max(n_temp[k]))
            ind = z.index((max(z)))
            max_N_temp = max(z)
            if max_N_temp >= thr[t_tasks[l]]:
                B_large.append(t_tasks[l])
            else:
                B_small.append(t_tasks[l])
            temp_et.remove(temp_et[ind])
            x=ACT_s[t_tasks[l]]
            for j in range(len(temp_et)):
                    d=VM_assign[t_tasks[l]]
                    temp_et[j][d]+=x
            print("updated temp :",np.matrix(temp_et))
            print("min_temp :", min_ect)
            print("max_temp :", max_ect)
            print(np.matrix(n_temp))
            print("Maximum value of current N_temp:", max_N_temp)
            print("B_large :", B_large)
            print("B_small :", B_small)
def NMMWS_WorkFlow_Scheduling():                             # main algorithm implementation (algorithm-1)------------------------------------------------------
    COMP_EFT(EST, EFT)
    NORM_PARTITION(EST, EFT, B_large, B_small, thr)
    if B_large!=[]:
        map_t=[]
        map_vm=[]
        ACT_t=[]
        for k in range(len(B_large)):
            z = []
            for i in range(len(B_large)):
                z.append(EFT[B_large[i]])
            min_bl = min(z)
            ind = z.index(min(z))
            map_t.append(B_large[ind])
            map_vm.append(VM_assign[B_large[ind]])
            ACT_t.insert(B_large[ind],EFT[B_large[ind]])
            B_large.remove(B_large[ind])
        print("Tasks in Larger batch after mapped :", map_t)
        print("mapped_vm's of each  task in Larger batch :", map_vm)
    if B_small!=[]:
        map_t=[]
        map_vm=[]
        ACT_t=[]
        for k in range(len(B_small)):
            z = []
            for i in range(len(B_small)):
                z.append(EFT[B_small[i]])
            min_bl = min(z)
            ind = z.index(min(z))
            map_t.append(B_small[ind])
            map_vm.append(VM_assign[B_small[ind]])
            ACT_t.insert(B_small[ind],EFT[B_small[ind]])
            B_small.remove(B_small[ind])
        print("Tasks in smaller batch after mapped :",map_t)
        print("mapped_vm's of each  task in smaller batch :",map_vm)
if __name__=="__main__":
    NMMWS_WorkFlow_Scheduling()
    # Given Factors Calculation
    # 1.Avg VM Utilization
    print("@@@@@@@@@@@@@@@@@@@@@@@", "Factors Calculation Part @@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    Mks = max(EFT)
    print("Makespan Overall: ", Mks)  # overall makespan
    t_2 = []
    t_2_ = []
    for i in range(vm):
        if i in c0_vm:
            for j in range(r):
                if i == VM_assign[j]:
                    t_2.append(EFT[j])
        else:
            for j in range(r):
                if i == VM_assign[j]:
                    t_2_.append(EFT[j])
    print("Makespan for cs-1 :", max(t_2))
    print("Makespan for cs-2 :", max(t_2_))
    Vm_util = []
    AWT = []  # actual Working Time
    for i in range(vm):
        ss = []
        for j in range(r):
            if i == VM_assign[j]:
                ss.append(EFT[j])
        print("Execution time of Tasks Executing in Vm " + str(i) + " :", ss)
        if ss == []:
            ss.append(0)
            AWT.append(sum(ss))
        else:
            if i in c0_vm:
                Vm_util.append(max(ss) / max(t_2))
            else:
                Vm_util.append(max(ss) / max(t_2_))
            AWT.append(sum(ss))
    print("Actual Working Time :", AWT)
    print("VM utilization Individually Labelled from 0-4 respectively :", Vm_util)
    Avg_Vm_util = sum(Vm_util) / vm  # average vm utilization
    Avg_util = (Avg_Vm_util / len(c0_vm)) * 100  # avg cloud utilization
    print()
    print("Average cloud Utilization is :", Avg_util, "%")
    # speedup
    EET = sum(ACT_s)  # sequential Execution time is the time taken for all tasks
    speedup = EET / Mks
    print()
    print("speedup is :", round(speedup))
    # Load balancing Factor -1
    import math as m

    RTL = []
    for i in range(vm):
        ss = []
        for j in range(r):
            if i == VM_assign[j]:
                ss.append(EFT[j])
        if ss == []:
            ss.append(0)
        RTL.append(max(ss))
    print()
    # print(" Max.Makespan of  Vm 's :" ,RTL)
    print()
    Avg_RTL = sum(RTL) / vm
    # print(Avg_RTL)
    LB_sum = 0
    for i in range(vm):
        LB_sum += (Avg_RTL - RTL[i]) ** 2
    LB_1 = m.sqrt(LB_sum / vm)
    print("Load Balancing Factor -1: ", LB_1)
    print()
    # Load Balancing Factor -2
    import statistics as st

    LB_sum_1 = 0
    for i in range(len(Vm_util)):
        LB_sum_1 += ((Vm_util[i] - Avg_Vm_util) ** 2)
    SD = m.sqrt(LB_sum_1 / vm)
    LB_2 = (abs(Avg_Vm_util - SD) / Avg_Vm_util) * 100
    print("LoadBalacing Factor-2  : ", LB_2, "%")
    # Energy Factor
    c_load = 1
    energy = 0
    import random

    for i in range(r):
        energy += c * ((random.random()) ** 2) * (random.random()) * int(ACT_s[i])
    print()
    print("Energy Factor-1 : ", energy)
    print()
    # Energy Factor -2
    T_energy = 0
    E_busy = 0.7  # Given
    E_idle = 0.2  # Given
    SL = 0.1  # Given
    for i in range(vm):
        T_energy += ((AWT[i] * E_busy) + (SL - AWT[i]) * E_idle)
    print("Energy Factor -2 :", T_energy)
    print()
    # cost Factor
    a = random.random()
    Vm_basePrice = 9.50  # base price charged for amazon EC2 for slowest vm per month in dollars
    T_unit_time = 10
    cpu_cycles = []
    for j in range(vm):
        s = VM_assign.count(j)
        cpu_cycles.append(s)
    # print("cpu_cycles of Vm's :",cpu_cycles)
    if min(cpu_cycles) == 0:
        slowest_cpu_cycle = 1
    else:
        slowest_cpu_cycle = min(cpu_cycles)
    # print(slowest_cpu_cycle)
    cost = 0
    for j in range(vm):
        for i in range(r):
            cost += a * (ACT_s[i] / T_unit_time) * Vm_basePrice * (m.exp(cpu_cycles[j] / slowest_cpu_cycle))
    print("Total Cost  :", cost)
